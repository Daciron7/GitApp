import React, { Component } from 'react'
import warshipInfo from './Warship_stuff/warship_info.json'
import './warships.css'

const warships = warshipInfo.meta[0].warships
const total = warships.filter(warship => warships.total === "411")

class Warships extends Component {
    render() {
        return (
        <div>
            <h1>(warships.length) Warships</h1>
            <h2>Total number: {total.length}</h2>
            
            
        </div>
        )
    }
}

export default Warships